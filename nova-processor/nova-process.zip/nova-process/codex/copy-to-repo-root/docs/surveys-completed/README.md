# Surveys Completed

This directory stores completed exit surveys produced by agents when prompted by Nova.

Files here are artifacts.
Do not edit past surveys.
